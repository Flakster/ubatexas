(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__2c70ea4f._.css",
  "static/chunks/node_modules_38254b73._.js",
  "static/chunks/src_b8fac260._.js"
],
    source: "dynamic"
});
